using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class NetStart : MonoBehaviour
{
    [Header("��������Ϣ")]
    public string host = "127.0.0.1";
    public int port = 32510;

    [Header("��¼����")]
    public InputField usernameInput;
    public InputField passwordInput;

    // Start is called before the first frame update
    void Start()
    {
        NetClient.ConnectToServer(host, port);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Login()
    {
        
    }
}
