using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Summer;
using System.Net;
using System.Net.Sockets;
using Summer.Network;
using System;
using Google.Protobuf;

/// <summary>
/// ����ͻ���
/// </summary>
public class NetClient
{

    private static Connection conn = null;

    public static void Send(IMessage message)
    {
        if(conn != null)
        {
            conn.Send(message);
        }
    }


    /// <summary>
    /// ���ӵ�������
    /// </summary>
    /// <param name="host"></param>
    /// <param name="port"></param>
    public static void ConnectToServer(string host, int port)
    {
        //�������ն�
        IPEndPoint ipe = new IPEndPoint(IPAddress.Parse(host), port);
        Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        socket.Connect(ipe);
        Debug.Log("���ӵ������");
        conn = new Connection(socket);
        conn.OnDisconnected += OnDisconnected;
        //������Ϣ�ַ���
        MessageRouter.Instance.Start(4);
    }

    //���ӶϿ�
    private static void OnDisconnected(Connection sender)
    {
        Debug.Log("��������Ͽ�");
    }
    
}
