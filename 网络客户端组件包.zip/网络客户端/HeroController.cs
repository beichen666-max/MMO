using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HeroController : MonoBehaviour
{
    //根据标签player获取英雄对象
    GameObject hero;
    public Camera camera;
    public Joystick joystick;
    public Joystick cameraJoystick;     //镜头角度
    public Joystick cameraJoystick2;    //镜头距离

    public float speed = 2; //每秒移动的距离

    private Animator heroAnimator;

    //是否调整视角
    public bool AdjustView{get; set;}
    //是否调整距离
    public bool AdjustDistance{get; set;}
    
    public bool IsAttacking {
        get {
            return heroAnimator.GetInteger("state") == 2;
        }
    }
    public bool IsJumping {
        get {
            //检测hero与terrain是否发生碰撞
            return heroAnimator.GetInteger("state") == 3; 
            
        }
    }

    //记录摄像机相对位置
    Vector3 offset;

    private bool mAttackOrder = false;
    public void SetAttackOrder(bool order){
        mAttackOrder = order;
    }


    // Start is called before the first frame update
    void Start()
    {
        heroAnimator = GetComponentInChildren<Animator>();
        //根据标签player获取英雄对象
        hero = this.gameObject;
        var chest = transform.Find("chest");
        //摄像机移动到英雄后方且对准英雄
        camera.transform.position = hero.transform.position - hero.transform.forward * 8 + Vector3.up * 3;
        camera.transform.LookAt(hero.transform);
        offset = camera.transform.position - hero.transform.position;
    }

    Vector2 touchOrigin; //触摸起始位置
    //双指缩放
    void PinchZoom()
    {
        
    }
    bool isEnlarge(Vector2 pos1, Vector2 pos2)
    {
        //计算出当前两点触摸点的位置
        float currentDistance = Vector2.Distance(pos1, pos2);
        //计算出上一次两点触摸点的位置
        float prevDistance = Vector2.Distance(pos1 - Input.GetTouch(0).deltaPosition, pos2 - Input.GetTouch(1).deltaPosition);
        //如果当前距离大于上一次距离，则放大手势成立
        if (currentDistance > prevDistance)
        {
            return true;
        }
        return false;
    }


    // Update is called once per frame
    void Update()
    {
        //摄像机跟随英雄移动
        camera.transform.position = hero.transform.position + offset;

        if(IsJumping && Physics.Raycast(hero.transform.position, Vector3.down, 0.2f))
        {

        }

        //获取动画播放到第几帧
        AnimatorStateInfo stateInfo = heroAnimator.GetCurrentAnimatorStateInfo(0);
        //Debug.Log("动画名称="+ stateInfo.IsName("Jump"));
        //如果动画播放50%
        //如果动画播放到攻击动画的最后一帧
        if (stateInfo.IsName("Jump") && stateInfo.normalizedTime > 0.5f)
        {
            //播放待机动画
            heroAnimator.SetInteger("state", 0);
        }


        //判断Button组件是否处于按下状态
        if (mAttackOrder)
        {
            Attack();
        }

        if (Application.platform == RuntimePlatform.Android || Application.platform == RuntimePlatform.WindowsEditor)
        {
            PinchZoom();
            if (cameraJoystick != null)
            {
                //控制摄像机绕英雄旋转
                float x = cameraJoystick.Horizontal;
                float y = cameraJoystick.Vertical;
                camera.transform.RotateAround(hero.transform.position, Vector3.up, x * 1.0f);
                camera.transform.RotateAround(hero.transform.position, camera.transform.right, -y * 1.0f);
                offset = camera.transform.position - hero.transform.position;
            }
            if(cameraJoystick2 != null)
            {
                //控制摄像机距离英雄的距离
                float wheel = cameraJoystick2.Vertical;
                if (wheel != 0)
                {
                    camera.transform.position += camera.transform.forward * 0.5f * wheel;
                    offset = camera.transform.position - hero.transform.position;
                }
            }
            
        }
        else
        {
            //鼠标滚轮控制摄像机距离英雄的距离
            float wheel = Input.GetAxis("Mouse ScrollWheel");
            if (wheel != 0)
            {
                camera.transform.position += camera.transform.forward * 1.5f * wheel;
                offset = camera.transform.position - hero.transform.position;
            }

            //鼠标右键控制摄像机绕英雄旋转
            if (Input.GetMouseButton(1))
            {
                Debug.Log("Mouse 0");
                float x = Input.GetAxis("Mouse X");
                float y = Input.GetAxis("Mouse Y");
                camera.transform.RotateAround(hero.transform.position, Vector3.up, x * 2);
                camera.transform.RotateAround(hero.transform.position, camera.transform.right, -y * 2);
                offset = camera.transform.position - hero.transform.position;
            }
        }

        //offset最大距离为20
        offset = Vector3.ClampMagnitude(offset, 20);
        

        //如果按下空格键执行跳跃
        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }
        

        //摇杆控制英雄移动
        float h = joystick.Horizontal;
        float v = joystick.Vertical;
        if(h==0)h=Input.GetAxis("Horizontal");
        if(v==0)v=Input.GetAxis("Vertical");
        if(!IsAttacking && !IsJumping)
        {
            //摇杆控制英雄旋转
            if (h != 0 || v != 0)
            {
                //摇杆控制英雄沿着摄像机的方向移动
                Vector3 dir = camera.transform.forward * v + camera.transform.right * h;
                dir.y = 0;
                dir.Normalize();
                hero.transform.position += dir * speed * Time.deltaTime;
                hero.transform.forward = dir;
                //播放跑步动画
                heroAnimator.SetInteger("state", 1);
            }else{
                //播放待机动画
                heroAnimator.SetInteger("state", 0);
            }
        }
        

        //用射线检测摄像机与英雄之间是否有障碍物
        RaycastHit hit;
        // if (Physics.Linecast(hero.transform.position, camera.transform.position, out hit))
        // {
        //     //临时移动摄像机到障碍物的位置
        //     camera.transform.position = hit.point;
        // }
        
        //射线检测摄像机不能穿过地面
        if (Physics.Linecast(hero.transform.position+Vector3.up*0.5f, camera.transform.position-Vector3.up*0.3f, out hit))
        {
            //临时移动摄像机到障碍物的位置
            camera.transform.position = hit.point + Vector3.up * 0.5f;
        }

    }


    private float lastAttackTime = 0;
    public void Attack(){
        if(IsAttacking) return;
        if(IsJumping) return;
        if (Time.time - lastAttackTime < 1) return;
        lastAttackTime = Time.time;
        heroAnimator.SetInteger("state", 2);
        //协程等待动画播放完毕
        StartCoroutine(WaitForAnimation());

    }

    IEnumerator WaitForAnimation()
    {
        yield return new WaitForSeconds(0.25f);
        Debug.Log("攻击完成");
        heroAnimator.SetInteger("state", 0);
    }

    public void AttackEnd()
    {
        
    }

    public float jumpHeight = 3;
    private Vector3 rootWorldPos = Vector3.zero;

    public void Jump(){
        if(IsAttacking) return;
        if (IsJumping) return;
        if (!Physics.Raycast(hero.transform.position, Vector3.down, 0.5f)) return;
        heroAnimator.SetInteger("state", 3);
        Debug.Log("跳跃");
        //StartCoroutine(WaitForJumpEnd());
        //给英雄一个向上的力
        var rigidbody = hero.GetComponent<Rigidbody>();
        //rigidbody.AddForce(Vector3.up * 50, ForceMode.Impulse);
        //给英雄一个向前的力
        //rigidbody.AddForce(hero.transform.forward * 5, ForceMode.Impulse);
    }
    IEnumerator JumpUp()
    {
        //跳跃时把heroAnimator的y轴相应的下移，因为heroAnimator自带上跃动画
        float t = 0;
        float y = hero.transform.position.y;
        while (t < 0.5f)
        {
            t += Time.deltaTime;
            hero.transform.position = new Vector3(hero.transform.position.x, y + jumpHeight * t, hero.transform.position.z);
            yield return null;
        }
        //StartCoroutine(JumpDown());
    }
    IEnumerator JumpDown()
    {
        float t = 0;
        float y = hero.transform.position.y;
        while (t < 0.5f)
        {
            t += Time.deltaTime;
            hero.transform.position = new Vector3(hero.transform.position.x, y - jumpHeight * t, hero.transform.position.z);
            yield return null;
        }
        StartCoroutine(WaitForJumpEnd());
    }

    IEnumerator WaitForJumpEnd()
    {
        yield return new WaitForSeconds(0.8f);
        Debug.Log("跳跃完成");
        heroAnimator.SetInteger("state", 0);
        //3d模型动画
    }
}
